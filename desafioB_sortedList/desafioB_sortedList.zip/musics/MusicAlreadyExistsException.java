package musics;

public class MusicAlreadyExistsException extends RuntimeException {
    public MusicAlreadyExistsException() {
        super();
    }
}
